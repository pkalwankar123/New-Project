package com.cg.assignment.utila;



import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;

public class Readfile {
		static int i=0;
	
		public static void main(String[] args) 
	    {
    
	            FileInputStream file = null;
				try {
					file = new FileInputStream(new File("C:\\PRADIP\\Book1.xls"));
					 HSSFWorkbook workbook = new HSSFWorkbook(file);
					 HSSFSheet sheet = workbook.getSheetAt(0);
					 DataFormatter formatter = new DataFormatter();
					 HashMap<Integer, HashMap<headerEnum, String>> hashMapOfAllRows = new HashMap<Integer,HashMap<headerEnum, String>>();
					 HashMap<Integer, HashMap<headerEnum, String>> Main = new HashMap<Integer, HashMap<headerEnum, String>>();
					 int countForEnum=1;
					
				
					Date date = new Date();  
				    SimpleDateFormat dformatter = new SimpleDateFormat("dd-MM");  
				    String strDate = dformatter.format(date);  
				    System.out.println("Date Format with MM/dd/yyyy : "+strDate);  
					
					while(countForEnum <= sheet.getLastRowNum())
					
					{
						 Row row1= sheet.getRow(countForEnum);
						// String chFive=headerEnum.values()[countForEnum].toString();
						
						 short length = row1.getLastCellNum();
						
						 HashMap<headerEnum, String> rowObject = new HashMap<headerEnum, String> ();
 							for (int J = 0; J < length; J++)
 								{
 							rowObject.put(headerEnum.values()[J], formatter.formatCellValue(row1.getCell(J)));
 								}
 							System.out.println(rowObject.toString());
 							
 							hashMapOfAllRows.put(countForEnum, rowObject);
 							System.out.println(rowObject.get(headerEnum.values()[2]));
 							System.out.println(strDate);
					if(rowObject.get(headerEnum.values()[2]).substring(0, 5).equalsIgnoreCase(strDate)) {
						Main.put(countForEnum,rowObject);
						
					}
					countForEnum++;
					
 							//hashMapOfAllRows.put(chFive, rowObject);
 							
 							/*if((rowObject.get(CoverageheaderEnum.values()[0]).equalsIgnoreCase("y")))
 							{
 							compare.put(chFive,rowObject);
 							}
 							
 							countForEnum++;
 							CO7++;*/}
					
					
					
					System.out.println(Main.toString());
					System.out.println(hashMapOfAllRows.toString());
					
					Set<String> coverage=new HashSet<String>();
					for (Entry<Integer, HashMap<headerEnum, String>> entry : Main.entrySet())
					{ 
						
						System.out.println(entry.getValue().get(headerEnum.values()[0]));
						System.out.println(entry.getValue().get(headerEnum.values()[1]));
					}
					
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				finally {
					try {
						file.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
					 
	    }		
	    
		
		
	/*	public static void  mail{
			String to = "receive@abc.om"; // sender 
			String from = "sender@abc.com"; // 
			String host = "127.0.0.1"; 
			Properties properties = System.getProperties(); properties.setProperty("mail.smtp.host", host); Session session = Session.getDefaultInstance(properties); // default session try { MimeMessage message = new MimeMessage(session); // email message message.setFrom(new InternetAddress(from)); // setting header fields message.addRecipient(Message.RecipientType.TO, new InternetAddress(to)); message.setSubject("Test Mail from Java Program"); // subject line // actual mail body message.setText("You can send mail from Java program by using mail API, but you need" + "couple of more JAR files e.g. smtp.jar and activation.jar"); // Send message Transport.send(message); System.out.println("Email Sent successfully...."); } catch (MessagingException mex) { mex.printStackTrace(); } } }
		}
*/
		
		
		private static Date parse(String pattern,String dateString) {
			if(dateString == null || dateString.isEmpty()) return null;

			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
			Date date = null;
			try {
				date = simpleDateFormat.parse(dateString);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			return date;
		}
		
		private static String format(String pattern,Date date) {
			if(date == null) return null;

			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
			return simpleDateFormat.format(date);
		}
		
	



			
			
public static boolean isCellDateFormatted(Cell cell) {
    if (cell == null) return false;
    boolean bDate = false;

//    double d = cell.getNumericCellValue();
//    if ( DateUtil.isValidExcelDate(d) ) {
        CellStyle style = cell.getCellStyle();
        if(style==null) return false;
        int i = style.getDataFormat();
        String f = style.getDataFormatString();
        bDate = DateUtil.isADateFormat(i, f);
//    }
    return bDate;
}		
			
			
}			
			
			
			
			
			
			
	

