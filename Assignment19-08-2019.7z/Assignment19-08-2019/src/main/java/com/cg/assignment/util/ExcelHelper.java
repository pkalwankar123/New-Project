package com.cg.assignment.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.regex.Pattern;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.Comment;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelHelper {

	public static void setComment(Cell cell, String message) {
		Drawing drawing = cell.getSheet().createDrawingPatriarch();
		CreationHelper factory = cell.getSheet().getWorkbook().getCreationHelper();

		// When the comment box is visible, have it show in a 1x3 space
		ClientAnchor anchor = factory.createClientAnchor();
		anchor.setCol1(cell.getColumnIndex());
		anchor.setCol2(cell.getColumnIndex() + 1);
		anchor.setRow1(cell.getRowIndex());
		anchor.setRow2(cell.getRowIndex() + 1);
		anchor.setDx1(100);
		anchor.setDx2(1000);
		anchor.setDy1(100);
		anchor.setDy2(1000);

		// Create the comment and set the text+author
		Comment comment = drawing.createCellComment(anchor);
		RichTextString str = factory.createRichTextString(message);
		comment.setString(str);
		cell.setCellComment(comment);
	}
	
	private static void readExcelFile(String fineName) {
		
		XSSFWorkbook workbookOutput = new XSSFWorkbook();
		
		Pattern pattern1 = Pattern.compile("^[0-3]?[0-9]/[0-3]?[0-9]/(?:[0-9]{2})?[0-9]{2}$");                             
         // Create cell style 
		/*CellStyle  backgroundStyle=workbookOutput.createCellStyle();;
        backgroundStyle.setFillBackgroundColor(IndexedColors.RED.getIndex());
       
        backgroundStyle.setFillForegroundColor(IndexedColors.RED.getIndex());
        
        
        backgroundStyle.setFillPattern(IndexedColors.RED.getIndex());  */
        
		Sheet ouputSheet = workbookOutput.createSheet();
		
		File file = new File(fineName);
		if(file.exists() && file.isFile()) {
			try {
				FileInputStream fileInputStream = new FileInputStream(file);
				
				 XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
				 
		         //Get first/desired sheet from the workbook
		         XSSFSheet sheet = workbook.getSheetAt(0);
		         
		         int rowCount = 0;
		         
		         Iterator<Row> rowIterator = sheet.iterator();
		         
		         while (rowIterator.hasNext()) {
					Row row = (Row) rowIterator.next();
					
					Row outputRow = ouputSheet.createRow(rowCount);
					
					int totalCell = row.getPhysicalNumberOfCells();
					
					System.out.println(row.getPhysicalNumberOfCells());
					
					for(int index=0; index < totalCell; index++) {
						
						Cell outputCell =  outputRow.createCell(index);
						
						Cell cell = row.getCell(index);
						
					
						
						if(cell!=null) {
						
							
							if(index == 7 && rowCount==2) {
								
								String astr="Pass";
						outputCell.setCellValue(astr);
									
									
								}
								
							
							else if(index == 0) {
								
								
								
								if(cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
									double cellData = cell.getNumericCellValue();
									outputCell.setCellValue(cellData);
									
									System.out.println();
								}
								else {
									outputCell.setCellValue("");
									//outputCell.setCellStyle(backgroundStyle);
									//setComment(cell, "Please provide some data");
								}
							}
							else if(index == 3)
						    {
								
								if(cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
									if(cell.getNumericCellValue()!=0 &&  pattern1.matcher(cell.getNumericCellValue()+"").matches()) {
										   //Date date= cell.getDateCellValue();
									       outputCell.setCellValue(cell.getStringCellValue());
									   }
									   else {
											outputCell.setCellValue("");
											//outputCell.setCellStyle(backgroundStyle);
											//setComment(cell, "Please provide some data");
										}
								}
								else if(cell.getCellType() == Cell.CELL_TYPE_STRING){
									if(cell.getStringCellValue()!=null && !"".equals(cell.getStringCellValue().trim()) &&  pattern1.matcher(cell.getStringCellValue()).matches()) {
									       outputCell.setCellValue(cell.getStringCellValue().trim());
									   }
									   else {
											outputCell.setCellValue("");
											//outputCell.setCellStyle(backgroundStyle);
											//setComment(cell, "Please provide some data");
										}
								}
								
						   }
							else {
								if(cell.getStringCellValue()!=null && !"".equals(cell.getStringCellValue().trim())) {
									String data=cell.getStringCellValue().trim();
								    outputCell.setCellValue(data);
								}
								else {
									outputCell.setCellValue("");
									//outputCell.setCellStyle(backgroundStyle);
									//setComment(cell, "Please provide some data");
								}
							}
						}
					}
					
					rowCount++;
				}
		         
		        // create excel file
		        OutputStream outputStream=new FileOutputStream("C:\\\\PRADIP\\\\19082019\\\\Final_DATA.xlsx");
		        workbookOutput.write(outputStream);
		        
		        System.out.println(" File Created ");
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
			System.err.println("Please provide valid file");
		
	}
	
	public static void main(String[] args) {
		final String inputFileName= "C:\\PRADIP\\19082019\\MOII_Scenarios.xlsx";
		readExcelFile(inputFileName);
	}

}
