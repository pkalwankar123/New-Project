/*package com.cg.assignment.utila;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Simple
{
	static FileOutputStream fos =null;
	static FileOutputStream fossuccess =null; 
    public static void main(String[] args) throws IOException
    {
    	HashMap<Integer,List<Cell>> hm=new HashMap<Integer,List<Cell>>();
    	StringBuffer buffer=new StringBuffer();
    	StringBuffer buffersuccess=new StringBuffer();
    	ExecutorService executorService = Executors.newFixedThreadPool(1);
    	File ferror=new File("C:\\\\PRADIP\\\\19082019\\\\MOII ScenarioError.csv");
    	File fsuccess=new File("C:\\\\PRADIP\\\\19082019\\\\MOII ScenarioSuccess.csv");
        
      
        
        try
        {
        	fos=new FileOutputStream(ferror);
        	fossuccess=new FileOutputStream(fsuccess);
            FileInputStream file = new FileInputStream(new File("C:\\\\PRADIP\\\\19082019\\\\MOII Scenarios.xlsx"));
 
            //Create Workbook instance holding reference to .xlsx file
            XSSFWorkbook workbook = new XSSFWorkbook(file);
 
            //Get first/desired sheet from the workbook
            XSSFSheet sheet = workbook.getSheetAt(0);
            
            //Iterate through each rows one by one
            Iterator<Row> rowIterator = sheet.iterator();
            
           
            
            int z=2;
            
            for(int ii=1;ii<=3;ii++) {
                
                hm.put(ii, new ArrayList<Cell>());
                }
            
            while (rowIterator.hasNext())
            {
            	
                Row row = rowIterator.next();
                Short s=row.getLastCellNum();
               
                int i=1;
                
              
                
                
                //For each row, iterate through all the columns
                Iterator<Cell> cellIterator = row.cellIterator();
                List<Cell> mylist=new ArrayList();
               
                while (cellIterator.hasNext()&&i<4)
                {
                    Cell cell = cellIterator.next();
                    
                    
                    hm.get(i).add(cell);
                    i++;
                    //System.out.println(cell.getColumnIndex());
                    //Check the cell type and format accordingly
                    
                     
//                    switch (cell.getCellType())
//                    {
//                        case Cell.CELL_TYPE_NUMERIC:
//                            System.out.print(cell.getNumericCellValue() + "t");
//                            break;
//                        case Cell.CELL_TYPE_STRING:
//                            System.out.print(cell.getStringCellValue() + "t");
//                            break;
//                    }
                }
                
               
                System.out.println("");
            }
            file.close();
            hm.forEach((key,value) -> System.out.println(key + " = " + value));
        }
        
        catch (Exception e)
        {
            e.printStackTrace();
        }
        Runnable task1 = () -> {
            
            
            
            hm.get(1).forEach( name -> 
                               {
                               if(name.getRowIndex()==0 && name.getColumnIndex()==0 || name.getCellType()==Cell.CELL_TYPE_NUMERIC) 
                               {
                            	  
                            	  buffersuccess.append(name+","+"\n");
                            	  System.out.println(name +"  is string"); 
                               }
                               else
                               {  
                            	   System.out.println(name + "  is not string");
                            	   buffersuccess.append(name+" ");
                            	  // hm.get(1).remove(name);
                               }
                               
                               
                               }
                               );
           
            
        
        };
            
       
            Runnable task2 = () -> {
                
            	
                hm.get(2).forEach( name -> 
                                   {
                                   if(name.getRowIndex()==1 && name.getColumnIndex()==1 || name.getCellType()==Cell.CELL_TYPE_STRING) 
                                   {
                                	   
                                	  buffersuccess.append(name+","+"\n");
                                	  System.out.println(name +"  is string"); 
                                   }
                                   else
                                   {  
                                	   System.out.println(name + "  is not string");
                                	   buffersuccess.append(name+" ");
                                	  // hm.get(1).remove(name);
                                   }
                                                               
                                   }
                                   );
                
                
                //System.out.println(buffersuccess.toString());
              	 try {
              		 
            		 //System.out.println(buffersuccess.toString().getBytes());
              		 //List<byte[]> by=Arrays.asList(a);
              		 
					fossuccess.write(buffersuccess.toString().getBytes());
					//fossuccess.write(buffersuccess.toString().getBytes());
					fos.write(buffer.toString().getBytes());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
              
      			
            
            };
           
     
           
            buffer.append("is not string");
          
          
          executorService.execute(task1);
          executorService.execute(task2);
          executorService.shutdown();
    }
}*/