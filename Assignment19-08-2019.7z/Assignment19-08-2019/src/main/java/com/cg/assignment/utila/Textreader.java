/*package com.cg.assignment.utila;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.List;

import javax.imageio.ImageIO;
import javax.imageio.stream.ImageInputStream;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

import com.cg.assignment.utila.*;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFPicture;
import org.apache.poi.xwpf.usermodel.XWPFPictureData;
import org.json.JSONArray;

public class Textreader {
	
	 
	   
	
	
	public static void main(String[] args)  {
		try {
			selectwORD();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
 }
	
	
	
	 public static void selectwORD() throws Exception{

		  JFileChooser chooser = new JFileChooser();
		     FileNameExtensionFilter filter = new FileNameExtensionFilter("DOCX","docx");
		     chooser.setFileFilter(filter);
		     chooser.setMultiSelectionEnabled(false);
		     int returnVal = chooser.showOpenDialog(null);
		     if(returnVal == JFileChooser.APPROVE_OPTION) {
		      File file=chooser.getSelectedFile();
		      System.out.println("Please wait...");     
		     
		      XWPFDocument xdoc = new XWPFDocument(OPCPackage.open(file.toString()));
			   List<XWPFPictureData> pics=xdoc.getAllPictures();
			   XWPFWordExtractor extractor = new XWPFWordExtractor(xdoc);
			   System.out.println(extractor.getText());
			   System.out.println(pics);
			   Textreader http=new Textreader();
			   String word = http.callUrlAndParseResult("es", "en", extractor.getText());
			   System.out.println(word);
		
		      
		      extractImages(file.toString());
		      System.out.println("Extraction complete");
		           }
		 }
	
	 public  String callUrlAndParseResult(String langFrom, String langTo,
             String word) throws Exception 
{

String url = "https://translate.googleapis.com/translate_a/single?"+
"client=gtx&"+
"sl=" + langFrom + 
"&tl=" + langTo + 
"&dt=t&q=" + URLEncoder.encode(word, "UTF-8");    

URL obj = new URL(url);
HttpURLConnection con = (HttpURLConnection) obj.openConnection(); 
con.setRequestProperty("User-Agent", "Mozilla/5.0");
//System.setProperty("http.agent", "");
BufferedReader in = new BufferedReader(
new InputStreamReader(con.getInputStream()));
String inputLine;
StringBuffer response = new StringBuffer();

while ((inputLine = in.readLine()) != null) {
response.append(inputLine);

}
in.close();
con.disconnect();
System.out.println(response.toString());
return parseResult(response.toString());
}

private  String parseResult(String inputJson) throws Exception
{


JSONArray jsonArray = new JSONArray(inputJson);
JSONArray jsonArray2 = (JSONArray) jsonArray.get(0);

JSONArray jsonArray3 = (JSONArray) jsonArray2.get(2);

return jsonArray3.get(0).toString();
}


public static void extractImages(String src){
	  try{
	  
	  //create file inputstream to read from a binary file
	  FileInputStream fs=new FileInputStream(src);
	  //create office word 2007+ document object to wrap the word file
	  XWPFDocument docx=new XWPFDocument(fs);
	  //get all images from the document and store them in the list piclist
	  List<XWPFPictureData> piclist=docx.getAllPictures();
	  //traverse through the list and write each image to a file
	  Iterator<XWPFPictureData> iterator=piclist.iterator();
	  int i=0;
	  while(iterator.hasNext()){
	   XWPFPictureData pic=iterator.next();
	   byte[] bytepic=pic.getData();
	   BufferedImage imag=ImageIO.read(new ByteArrayInputStream(bytepic));
	          ImageIO.write(imag, "jpg", new File("C:\\Users\\pkalwank\\Documents\\tp\\prad"+i+".jpg"));
	          i++;
	  }
	  
	  }catch(Exception e){System.exit(-1);}

}
}*/