package com.cg.assignment.util;

import java.io.File;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.openxml4j.opc.PackageAccess;

/**
*
* @author Administrator
*/
public class ReadExcelNdArray {


public static void main(String[] args) throws Exception {
	
	File directory= null;
	String[] ListDir= null;
	//int stamp = 0;
	
		System.gc();
		//if(stamp++>1000) { System.out.println(","); stamp=0;}else {System.out.println(",");}
		//Thread.sleep(2000);	
		directory = new File("C:\\PRADIP\\PRacto");
		ListDir = directory.list();
		
		
		if(ListDir.length>0) {
			
			File xlsxbor = new File("C:\\\\PRADIP\\\\PRacto\\"+ListDir[0]);
			OPCPackage p = OPCPackage.open(xlsxbor.getAbsolutePath(), PackageAccess.READ);
			System.out.println("started exe");
			long start = System.currentTimeMillis();
			XLsRead xls = new XLsRead(p, 14);
			xls.process();p.close();
			System.out.println("Time taken: " + (System.currentTimeMillis() - start) + " ms");
			/*FileInputStream xlsdStream= new FileInputStream(xlsxbor.getAbsolutePath());
			XSSFWorkbook xssfWorkbook =new XSSFWorkbook(xlsdStream);
			XSSFSheet xssfSheet= xssfWorkbook.getSheet("rId1");
			for(int i = 0; i < xssfSheet.getLastRowNum();i++){
				XSSFCell a1 = xssfSheet.getRow(i).getCell(0);
				XSSFCell a2 = xssfSheet.getRow(i).getCell(1);
				XSSFCell a3 = xssfSheet.getRow(i).getCell(2);
				System.out.print(a1.getStringCellValue());
				System.out.print(""+a2.getStringCellValue());
				System.out.print(""+a3.getStringCellValue());
			}
			xlsdStream.close();*/
			
		}
	
	
/*long start = System.currentTimeMillis();
BasicConfigurator.configure();
System.out.println("Time taken: " + (System.currentTimeMillis() - start) + " ms");



		  InputStream is = new FileInputStream(new File("C:\\\\PRADIP\\\\Book12.xlsx"));
		  @SuppressWarnings("deprecation")
		StreamingReader reader = (StreamingReader) StreamingReader.builder()
			        .rowCacheSize(100)    // number of rows to keep in memory (defaults to 10)
			        .bufferSize(4096)     // buffer size to use when reading InputStream to file (defaults to 1024)
			        .sheetIndex(0)        // index of sheet to use (defaults to 0)
			        .sheetName("rId1")  // name of sheet to use (overrides sheetIndex)
			        .open(is); 
		    for (Row r : reader) {
		      for (Cell c : r) {
		        System.out.println(c.getStringCellValue());
		      }
		    }
		  
*/

/*File myFile = new File("D://Raghulpr/Transaction Data.xlsx");
  FileInputStream fis = new FileInputStream(myFile);*/

 /* InputStream is = new FileInputStream(new File("C:\\PRADIP\\Book12.xlsx"));
  org.apache.poi.ss.usermodel.Workbook  workbook = StreamingReader.builder()
          .rowCacheSize(100)    
          .bufferSize(4096)     
          .open(is); 
  
  
  // Finds the workbook instance for XLSX file
  //XSSFWorkbook myWorkBook = new XSSFWorkbook (fis);

  // Return first sheet from the XLSX workbook
  XSSFSheet mySheet = (XSSFSheet) workbook.getSheetAt(0);

  // Get iterator to all the rows in current sheet
  Iterator<Row> rowIterator = mySheet.iterator();


//Traversing over each row of XLSX file
  while (rowIterator.hasNext()) {
      Row row = rowIterator.next();

      // For each row, iterate through each columns
      Iterator<Cell> cellIterator = row.cellIterator();
      while (cellIterator.hasNext()) {

          Cell cell = cellIterator.next();

          switch (cell.getCellType()) {
          case Cell.CELL_TYPE_STRING:
              System.out.print(cell.getStringCellValue() + "\t");
              break;
          case Cell.CELL_TYPE_NUMERIC:
              System.out.print(cell.getNumericCellValue() + "\t");
              break;
          case Cell.CELL_TYPE_BOOLEAN:
              System.out.print(cell.getBooleanCellValue() + "\t");
              break;
          default :

          }
      }
      System.out.println("");
  }
 */     
}
}
