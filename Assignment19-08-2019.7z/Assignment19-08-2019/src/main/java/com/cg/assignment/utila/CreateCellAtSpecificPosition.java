package com.cg.assignment.utila;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;


import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class CreateCellAtSpecificPosition { 
    public static void main(String[] args) throws FileNotFoundException, IOException 
    { 
        // Create a workbook instances 
        Workbook wb = new XSSFWorkbook(); 
  
        OutputStream os = new FileOutputStream("C:\\\\\\\\PRADIP\\\\\\\\19082019\\\\\\\\Geeks.xlsx"); 
  
        // Creating a sheet using predefined class provided by Apache POI 
        Sheet sheet = wb.createSheet("Company Prepration"); 
  
        // Creating a row at specific position 
        // using predefined class provided by Apache POI 
  
        // Specific row number 
       
        for(int i=0;i<10;i++) {
        Row row = sheet.createRow(i); 
  
        // Specific cell number 
        
        for(int j=0;j<10;j++) {
        
        Cell cell = row.createCell(j); 
  
        // putting value at specific position 
        cell.setCellValue("Geeks"); 
        }
        }
        // writing the content to Workbook 
        wb.write(os); 
  
        System.out.println("given cell is created at position (1, 1)"); 
    } 
} 