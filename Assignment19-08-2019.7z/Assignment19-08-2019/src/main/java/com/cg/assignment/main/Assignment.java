package com.cg.assignment.main;

public class Assignment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("hello World!");
	}

}
