package com.cg.assignment.utila;

import java.awt.Desktop;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFPictureData;

public class HelloWorldToHTML {

		public static void main(String[] args) {

			  selectwORD();
		}

		 public static void selectwORD(){

			  JFileChooser chooser = new JFileChooser();
			     FileNameExtensionFilter filter = new FileNameExtensionFilter("DOCX","docx");
			     chooser.setFileFilter(filter);
			     chooser.setMultiSelectionEnabled(false);
			     int returnVal = chooser.showOpenDialog(null);
			     if(returnVal == JFileChooser.APPROVE_OPTION) {
			      File file=chooser.getSelectedFile();
			      System.out.println("Please wait...");     
			      extractImages(file.toString());
			      System.out.println("Extraction complete");
			           }
			 }
		 
		 public static void extractImages(String src){
			  try{
			  String text;
			  //create file inputstream to read from a binary file
			  FileInputStream fs=new FileInputStream(src);
			  String mainChapterNumber = src.split("\\.", 2)[0];
			  String mainChapterNumberOne=mainChapterNumber.trim();
			  System.out.println(mainChapterNumberOne);
			  System.out.println(mainChapterNumber);
			  FileOutputStream fs1=new FileOutputStream(mainChapterNumber+".htm");
			  System.out.println(fs1);
			  
			  
			 
	    		broe(mainChapterNumber+".htm");
			 /* PrintWriter outputFile = new PrintWriter("files\\"+filename+".html");
			  //create office word 2007+ document object to wrap the word file
			  BufferedWriter out = new BufferedWriter(new FileWriter(src)); */
			 /* out.write(text);
			  out.close();*/
			  
			  }catch(Exception e){System.exit(-1);}}
			  
			  public static void broe(String fs1) {
		 
		 
		 try {
			 
			 
			 File afile =new File(fs1);
	    		
	    	  // afile.renameTo(new File("C:\\Users\\pkalwank\\Documents\\tp\\" + afile.getName()));
	    	   moveFile(fs1, "C:\\Users\\pkalwank\\Documents\\tp\\" + afile.getName());
	    		System.out.println("File is moved successful!");
			
			String str=new String("C:\\Users\\pkalwank\\Documents\\tp\\" + afile.getName());
			  
	            Runtime rtime = Runtime.getRuntime();

	          System.out.println(str);
	           // String brow = "C:\\installers\\Chrome\\Application\\chrome.exe";

	            Process pc = rtime.exec(fs1);    
	            pc.waitFor();       
	         } catch (Exception e) {
	              System.out.println("\n\n" + e.getMessage());
	         }
	    }
		 
			  

private static void moveFile(String src, String dest ) {
   Path result = null;
   try {
      result =  Files.move(Paths.get(src), Paths.get(dest));
   } catch (IOException e) {
      System.out.println("Exception while moving file: " + e.getMessage());
   }
   if(result != null) {
      System.out.println("File moved successfully.");
   }else{
      System.out.println("File movement failed.");
   }  
} 
			       
			  
			        
}
