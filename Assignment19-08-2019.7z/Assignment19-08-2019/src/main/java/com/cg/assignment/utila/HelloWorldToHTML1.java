/*package com.cg.assignment.utila;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.apache.poi.xwpf.usermodel.XWPFDocument;

import fr.opensagres.poi.xwpf.converter.core.FileURIResolver;
import fr.opensagres.poi.xwpf.converter.core.XWPFConverterException;
import fr.opensagres.poi.xwpf.converter.xhtml.XHTMLConverter;
import fr.opensagres.poi.xwpf.converter.xhtml.XHTMLOptions;
public class HelloWorldToHTML1 {
public static void main(String[] args) throws XWPFConverterException, IOException {

	  selectwORD();
}

public static void selectwORD() throws XWPFConverterException, IOException{

	  JFileChooser chooser = new JFileChooser();
	     FileNameExtensionFilter filter = new FileNameExtensionFilter("DOCX","docx");
	     chooser.setFileFilter(filter);
	     chooser.setMultiSelectionEnabled(false);
	     int returnVal = chooser.showOpenDialog(null);
	     if(returnVal == JFileChooser.APPROVE_OPTION) {
	      File file=chooser.getSelectedFile();
	      System.out.println("Please wait...");     
	     // extractImages(file.toString());
	      System.out.println("Extraction complete");
	      InputStream in= new FileInputStream(file);
	      XWPFDocument document = new XWPFDocument(in);


	      XHTMLOptions options = XHTMLOptions.create().URIResolver(new FileURIResolver(new File("word/media")));

	      OutputStream out = new ByteArrayOutputStream();


	      XHTMLConverter.getInstance().convert(document, out, options);
	      String html=out.toString();
	      System.out.println(html);
	      
	      
	           }
	 }
}
//convert .docx to HTML string
*/