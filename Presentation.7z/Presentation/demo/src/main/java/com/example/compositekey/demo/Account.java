package com.example.compositekey.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@IdClass(AccountId.class)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Account {
	@Id
	private String accountNumber;

	@Id
	private String accountType;
	@Column
	private String firstName;
	
	@Column
	private String lastName;

}
