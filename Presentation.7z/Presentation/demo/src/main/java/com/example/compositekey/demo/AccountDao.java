package com.example.compositekey.demo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AccountDao extends JpaRepository<Account,AccountId> {

}
