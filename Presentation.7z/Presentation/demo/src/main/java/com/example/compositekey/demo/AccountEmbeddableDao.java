package com.example.compositekey.demo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AccountEmbeddableDao extends JpaRepository<AccountEmbeddable,AccounIdEmbedded> {

}
