package com.example.compositekey.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApplication implements CommandLineRunner {

	@Autowired
	private AccountDao accDao;
	
	@Autowired
	private AccountEmbeddableDao accEmbDao;

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}
	
	/**
	 * IdClass Save 
	 */
	@Override
    public void run(String... args) throws Exception {
        accDao.save(new Account("1234564", "aa", "amit", "shinde"));
        
    }
	
	/**
	 * IdClass Fetch 
	 */
	/*@Override
    public void run(String... args) throws Exception {
		
		
        System.out.println(accDao.findById(new AccountId("1234564", "aa")));
        
    }*/
	
	/**
	 * EmbeddedId Save 
	 */
	/*@Override
    public void run(String... args) throws Exception {
		
		AccountEmbeddable a1 = new AccountEmbeddable();
		a1.setAccounIdEmbedded(new AccounIdEmbedded("111222", "Savings"));
		a1.setFirstName("Pradip");
		a1.setLastName("kalwankar");
        System.out.println(accEmbDao.save(a1));
        
    }*/
	
	/**
	 * EmbeddedId Fetch 
	 */
	/*@Override
    public void run(String... args) throws Exception {
		
        System.out.println(accEmbDao.findById(new AccounIdEmbedded("111222", "Savings")).get());
        
    }*/

}
