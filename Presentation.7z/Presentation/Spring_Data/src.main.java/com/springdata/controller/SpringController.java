package com.springdata.controller;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.springdata.persistance.dao.DepartmentRepository;
import com.springdata.persistance.dao.EmployeeRepository;
import com.springdata.persistance.model.Department;
import com.springdata.persistance.model.DepartmentId;
import com.springdata.persistance.model.Employee;
import com.springdata.persistance.model.EmployeeId;
import com.springdata.service.EmployeeService;

@RestController
@RequestMapping("/")
@CrossOrigin(origins = "*", methods= {RequestMethod.GET,RequestMethod.POST})
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class SpringController {

	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Autowired
	private DepartmentRepository departmentRepository;
	

	
	@Autowired
	@Qualifier("eService")
	private EmployeeService employeeService;
	
	@GetMapping("/test")
	public String test(){
		
		Class klass = SpringController.class;
			
		Annotation[] annotationList = klass.getDeclaredAnnotations();
		
		for(Annotation annotation : annotationList) {
			System.out.println(annotation);
		}
		
		Method[]  methodList = klass.getMethods();
		
		for(Method method : methodList) {
			System.out.println("================="+method.getName()+"=================");
			Annotation[] methodAnnotationList = method.getDeclaredAnnotations();
			
			for(Annotation annotation : methodAnnotationList) {
				System.out.println(annotation);
			}
		}
		
		return "Welcome to Spring DATA";
	}
	
	@GetMapping("/emp")
	public Employee getEmployee(){
		return new Employee();
	}
	
	@GetMapping("/empbyId")
	public Employee getEmployeeById(@RequestParam("idEmployee") Integer idEmployee ,@RequestParam("branchName") String branchName 
			 ,@RequestParam("departmentId") Long departmentId ,@RequestParam("deptName") String  deptName){
		return  employeeRepository.findById(new EmployeeId(idEmployee, branchName, new Department(new DepartmentId(departmentId, deptName)))).orElse(null);
	}
	
	@GetMapping("/alldept")
	public List<Department> getDepartment(){
		return  departmentRepository.findAll();
	}
	
	@GetMapping("/allemp")
	public List<Employee> getAllEmployee(){
		return employeeRepository.findAllEmployee();
	}
	
	@PostMapping("/saveemp")
	public ResponseEntity saveEmployee(@RequestBody @Valid Employee employee,BindingResult bindingResult){
		
		if (bindingResult.hasErrors())
		{
			List<FieldError> errorsList = bindingResult.getFieldErrors();
			if(errorsList!=null && !errorsList.isEmpty()) 
			{
				Map<String, String> errorMap = new LinkedHashMap<>();
				for( FieldError fieldError : errorsList) 
				{
					errorMap.put(fieldError.getField(), fieldError.getDefaultMessage());
				}
				return new ResponseEntity(errorMap, HttpStatus.BAD_REQUEST);
			}
		}
		
		departmentRepository.save(employee.getEmployeeId().getDepartment());
		return new ResponseEntity(employeeRepository.save(employee), HttpStatus.OK);
	}
	
	@GetMapping("/empId/{id}")
	public List<Employee> getEmployeeByEmpId(@PathVariable("id") Integer idEmployee){
		return  employeeRepository.findByEmpId(idEmployee);
	}
}
