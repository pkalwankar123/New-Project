package com.springdata.persistance.model;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.Size;

@Entity(name="Emp")
@Table(name="EMPLOYEE")
public class Employee   implements Serializable
{
	@EmbeddedId
	private EmployeeId employeeId;
 
	@Size(max=12,message="firstname should be of max 12 characters")
	private String firstName;
	
	private String lastName;
	private Integer salary;
	
	public Employee()
	{
	}


	public EmployeeId getEmployeeId() {
		return employeeId;
	}


	public void setEmployeeId(EmployeeId employeeId) {
		this.employeeId = employeeId;
	}

	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public Integer getSalary() {
		return salary;
	}


	public void setSalary(Integer salary) {
		this.salary = salary;
	}
	
}
