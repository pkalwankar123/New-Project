package com.springdata.service;

import java.util.List;

import com.springdata.persistance.model.Employee;

public interface EmployeeService {
	public List<Employee> findByEmpId(Integer idEmployee);
}
