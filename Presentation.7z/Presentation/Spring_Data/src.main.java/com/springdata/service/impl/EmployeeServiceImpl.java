package com.springdata.service.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.springdata.persistance.model.Employee;
import com.springdata.service.EmployeeService;

@Service("eService")
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class EmployeeServiceImpl implements EmployeeService {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Employee> findByEmpId(Integer idEmployee) {

		List<Employee> list = null;

		Query query = entityManager
				.createQuery("SELECT emp FROM Emp emp WHERE emp.employeeId.idEmployee = :idEmployee ");

		query.setParameter("idEmployee", idEmployee);

		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

}
