package com.hibernate4.demo.client;

import java.util.List;

import java.util.*;
import org.hibernate.*;

import com.hibernate4.demo.entity.Department;



public class HibernateTest {
	/*
	 * static SessionFactory factory ; static { factory = getSessionFactory(); }
	 * 
	 * private static void addData() { Session session = factory.openSession();
	 * session.save(new Department("HR")); session.save(new Department("FINANCE"));
	 * session.save(new Department("ADMINISTRATOR")); session.close(); }
	 * 
	 * public static void main(String[] args) { Session session= null; Transaction
	 * transaction= null; try { session = factory.openSession(); transaction =
	 * session.beginTransaction();
	 * 
	 * // Executing named queries session.crea List<Long>
	 * totalDept=session.createNamedQuery("get_total_dept",Long.class).getResultList
	 * (); System.out.println("Total Department: "+totalDept.get(0));
	 * 
	 * List<String>
	 * deptName=session.createNamedQuery("get_dept_name_by_id",String.class)
	 * .setParameter("id", 2) .getResultList(); for (Object object : deptName) {
	 * System.out.println(object); }
	 * 
	 * List<Department>
	 * departments=session.createNamedQuery("get_all_dept",Department.class)
	 * .getResultList(); for (Department department : departments) {
	 * System.out.println("ID : "+department.getId()+" \tNAME : "+department.getName
	 * ()); } transaction.commit(); } catch (Exception e) { e.printStackTrace(); }
	 * finally { if (session != null) { session.close(); } }
	 * 
	 * 
	 * 
	 * Session session = factory.openSession(); addData();
	 * 
	 * Criteria criteria = session.createCriteria(Department.class);
	 * 
	 * criteria.list().stream().forEach(System.out::println);
	 * 
	 * session.close(); }
	 * 
	 * private static SessionFactory getSessionFactory() { Configuration
	 * configuration = new Configuration();
	 * configuration.setProperty("hibernate.connection.driver_class",
	 * "com.microsoft.sqlserver.jdbc.SQLServerDriver");
	 * configuration.setProperty("hibernate.connection.url",
	 * "jdbc:sqlserver://localhost;databaseName=PRACTICE");
	 * configuration.setProperty("hibernate.connection.username", "sa");
	 * configuration.setProperty("hibernate.connection.password", "admin@123");
	 * configuration.setProperty("hibernate.dialect",
	 * "org.hibernate.dialect.SQLServer2012Dialect");
	 * configuration.setProperty("hibernate.hbm2ddl.auto", "update");
	 * configuration.setProperty("show_sql", "true");
	 * 
	 * configuration.addAnnotatedClass(Department.class);
	 * configuration.addAnnotatedClass(Employee.class);
	 * configuration.addAnnotatedClass(PersonInfo.class);
	 * 
	 * return configuration.buildSessionFactory(); }
	 */

	public static void main(String[] args) {
		Session session = null;
		Transaction transaction = null;
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			transaction = session.beginTransaction();

			// Executing named queries

			List<Long> totalDept = session.createNamedQuery("get_total_dept", Long.class).getResultList();
			
			System.out.println("Total Department: " + totalDept.get(0));

			List<String> deptName = session.createNamedQuery("get_dept_name_by_id", String.class).setParameter("id", 2)
					.getResultList();
			for (Object object : deptName) {
				System.out.println(object);
			}

			List<Department> departments = session.createNamedQuery("get_all_dept", Department.class).getResultList();
			for (Department department : departments) {
				System.out.println("ID : " + department.getId() + " \tNAME : " + department.getName());
			}
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}
		HibernateUtil.shutdown();
	}

}
