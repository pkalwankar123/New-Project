package com.hibernate4.demo.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class PersonInfo implements Serializable {
	@Id
	@Column(name = "PERSONINFOID")
	private Long personInfoId;

	@Id
	@Column(name = "NAME")
	private String name;

	private String email;

	private Integer age;

	public PersonInfo() {
	}

	public Long getPersonInfoId() {
		return personInfoId;
	}

	public void setPersonInfoId(Long personInfoId) {
		this.personInfoId = personInfoId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}
}
