package com.hibernate4.demo.entity;

import java.util.Calendar;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import com.hibernate4.demo.client.HibernateUtil;

public class ProductService {

	private static SessionFactory sessionFactory = HibernateUtil.getSessionFactory();

	public static List<Product> getProducts() {
		Session session = sessionFactory.openSession();
		List<Product> product = session.createNativeQuery("select * from product",Product.class).list();
		return product;
	}

	private static void saveProduct(Product product) {
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Query<Product> query = session.createNativeQuery(
				"" + "INSERT INTO product(product_id,manufactured_date,price,product_code,product_name,vat)VALUES(:product_id,:manufactured_date,:price,:product_code,:product_name,:vat)");
		query.setParameter("product_id", product.getId());
		query.setParameter("manufactured_date", product.getManufacturedDate());
		query.setParameter("price", product.getPrice());
		query.setParameter("product_code", product.getProductCode());
		query.setParameter("product_name", product.getProductName());
		query.setParameter("vat", product.getVat());
		query.executeUpdate();
		session.getTransaction().commit();
	}

	public static void main(String[] args) {
		Product product = new Product();
		product.setManufacturedDate(Calendar.getInstance().getTime());
		AtomicInteger ai=new AtomicInteger(100);
		
		product.setId(ai.getAndIncrement());
		product.setPrice(20);
		product.setProductCode("TP001");
		product.setProductName("Tooth Paste");
		product.setVat(2);
		saveProduct(product);
		System.out.println("Total product in database - " + getProducts().size());
	}
}