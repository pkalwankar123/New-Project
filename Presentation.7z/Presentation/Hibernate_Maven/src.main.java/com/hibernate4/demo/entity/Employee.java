package com.hibernate4.demo.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;

@Entity
public class Employee   implements Serializable
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long employeeId;
	
	private Double employeeSalary;
	
	@ManyToOne
	@JoinColumns(foreignKey=@ForeignKey(name = "FK_T_INS_INF1"),
	value={
	  @JoinColumn(name="PERSONINFOID",referencedColumnName = "PERSONINFOID", insertable = false, updatable = false),
	  @JoinColumn(name="NAME",referencedColumnName = "NAME", insertable = false, updatable = false)
	})
	private PersonInfo personInfo;
	
	@ManyToOne
	@JoinColumn(name="departmentId")
	private Department department;
	
	public Employee()
	{
	}

	public Long getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}

	public Double getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(Double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

	public PersonInfo getPersonInfo() {
		return personInfo;
	}

	public void setPersonInfo(PersonInfo personInfo) {
		this.personInfo = personInfo;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}
	
}
