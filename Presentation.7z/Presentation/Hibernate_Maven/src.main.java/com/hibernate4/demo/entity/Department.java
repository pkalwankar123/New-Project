package com.hibernate4.demo.entity;
/*
import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Department    implements Serializable
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long departmentId;
	
	private String  deptName;
	
	public Department() {
	}
	
	public Department(String deptName) {
		super();
		this.deptName = deptName;
	}



	public Long getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Long departmentId) {
		this.departmentId = departmentId;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	@Override
	public String toString() {
		return "Department [departmentId=" + departmentId + ", deptName=" + deptName + "]";
	}
	
}*/

import java.util.*;
import javax.persistence.*;

import lombok.Data;
@Data
@Entity
@Table(name="DEPARTMENT")

//Using @NamedQuery for single JPQL or HQL
@NamedQuery(name="get_total_dept", query="select count(1) from Department")

//Using @NamedQueries for multiple JPQL or HQL
@NamedQueries({
   @NamedQuery(name="get_dept_name_by_id", query="select name from Department where id=:id"),
   @NamedQuery(name="get_all_dept", query="from Department")
})

public class Department {
   @Id
   @Column(name = "DPT_ID")
   private int id;

   @Column(name = "NAME")
   private String name;

 /*  @OneToMany(cascade = CascadeType.ALL, mappedBy = "department")
   private List<Employee> employees = new ArrayList<>();*/

  
}
