package com.capgemini.JPADemo;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


//@NamedStoredProcedureQuery(name="projectName", procedureName="PRC_GET_PROJECT_NAME",  parameters={
	   // @StoredProcedureParameter(name = "V_NAME", type = String.class, mode = ParameterMode.IN),
	   // @StoredProcedureParameter(name = "V_PROJECT_NAME", type = String.class, mode = ParameterMode.OUT)})
@Entity
@Table(name="TEST_TEAM")
//@NamedNativeQuery(
	   // name = "SelectCount",
	    //query = "SELECT COUNT(*) FROM TEST_TEAM")
@NamedQuery(
	    name = "SelectName",
	    query = "SELECT name FROM TestTeam t WHERE t.id=:ID")
public class TestTeam {
	@Id
	private Long id;
	private Long salary;
	private String name;
	private String specification;
	private Long experience;
	@Column(name="project_id")
	private Long projectId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getSalary() {
		return salary;
	}

	public void setSalary(Long salary) {
		this.salary = salary;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSpecification() {
		return specification;
	}

	public void setSpecification(String specification) {
		this.specification = specification;
	}

	public Long getExperience() {
		return experience;
	}

	public void setExperience(Long experience) {
		this.experience = experience;
	}

	public Long getProjectId() {
		return projectId;
	}

	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}

	@Override
	public String toString() {
		return "TestTeam [id=" + id + ", salary=" + salary + ", name=" + name + ", specification=" + specification
				+ ", experience=" + experience + ", projectId=" + projectId + "]";
	}

	public TestTeam(Long id, Long salary, String name, String specification, Long experience, Long projectId) {
		super();
		this.id = id;
		this.salary = salary;
		this.name = name;
		this.specification = specification;
		this.experience = experience;
		this.projectId = projectId;
	}

	public TestTeam() {

	}

}
