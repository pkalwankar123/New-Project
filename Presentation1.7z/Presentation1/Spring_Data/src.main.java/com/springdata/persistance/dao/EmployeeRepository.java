package com.springdata.persistance.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.springdata.persistance.model.Employee;
import com.springdata.persistance.model.EmployeeId;
import com.springdata.service.EmployeeService;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, EmployeeId> , EmployeeService {
	
	@Query("SELECT emp FROM Emp emp")
	public List<Employee> findAllEmployee();
}
