package com.springdata.persistance.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;

@Embeddable
public class EmployeeId implements Serializable
{
	@Column(name="EMP_ID")
	private Integer idEmployee;
	
	@Column(name="EMP_BRANCH")
	private String branchName;
	
	@ManyToOne(fetch= FetchType.EAGER)
	@JoinColumns(foreignKey=@ForeignKey(name = "FK_DEPT"),
	value={
	  @JoinColumn(name="DEPT_ID",referencedColumnName  = "DEPT_ID", insertable = false, updatable = false),
	  @JoinColumn(name="DEPT_NAME",referencedColumnName = "DEPT_NAME", insertable = false, updatable = false)
	})
	private Department department;
 
	public EmployeeId() {
 
	}

	public EmployeeId(Integer idEmployee, String branchName, Department department) {
		super();
		this.idEmployee = idEmployee;
		this.branchName = branchName;
		this.department = department;
	}



	public Integer getIdEmployee() {
		return idEmployee;
	}
 
	public String getBranchName() {
		return branchName;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public void setIdEmployee(Integer idEmployee) {
		this.idEmployee = idEmployee;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((branchName == null) ? 0 : branchName.hashCode());
		result = prime * result + ((department == null) ? 0 : department.hashCode());
		result = prime * result + idEmployee;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmployeeId other = (EmployeeId) obj;
		if (branchName == null) {
			if (other.branchName != null)
				return false;
		} else if (!branchName.equals(other.branchName))
			return false;
		if (department == null) {
			if (other.department != null)
				return false;
		} else if (!department.equals(other.department))
			return false;
		if (idEmployee != other.idEmployee)
			return false;
		return true;
	}
	
	
}
