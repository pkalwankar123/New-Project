package com.springdata.persistance.model;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity(name="Dept")
@Table(name="DEPARTMENT")
public class Department    implements Serializable
{
	@EmbeddedId
	private DepartmentId departmentId;
	
	public Department() {
	}

	public Department(DepartmentId departmentId) {
		super();
		this.departmentId = departmentId;
	}

	public DepartmentId getDepartmentId() {
		return departmentId;
	}


	public void setDepartmentId(DepartmentId departmentId) {
		this.departmentId = departmentId;
	}
}
