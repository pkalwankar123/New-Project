package com.capgemini.JPADemo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	/*EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("Persistence1");
    	EntityManager entityManager= entityManagerFactory.createEntityManager();
    	*/
    	EntityManagerFactory factory = Persistence.createEntityManagerFactory("Persistence2");
		EntityManager em = factory.createEntityManager();
    	System.out.println("jdflkg");
		List<TestTeam> listTeam=null;
		
    	//find
    	System.out.println("*****Team Details*****");
    	listTeam= em.createQuery(" FROM TestTeam t").getResultList();
 		for (TestTeam p : listTeam) {
 			System.out.println(p);
 		}
 		
    	/*TestTeam team= em.find(TestTeam.class, 1L);
        System.out.println("find:"+team);*/
        /*
        //persist
		entityManager.getTransaction().begin();
		TestTeam person = new TestTeam(17L, 20000L, "TEST", "TESTER", 2L, 2L);
		entityManager.persist(person);
		entityManager.getTransaction().commit();
    
		System.out.println("*****Team Details*****");
		listTeam = entityManager.createQuery(" FROM TestTeam t").getResultList();
		for (TestTeam p : listTeam) {
			System.out.println(p);
		}
       
		//remove
		entityManager.getTransaction().begin();	
		entityManager.remove(person);
		entityManager.getTransaction().commit();
		
		 System.out.println("*****Team Details*****");
    	 listTeam = entityManager.createQuery(" FROM TestTeam t").getResultList();
		for (TestTeam p : listTeam) {
			System.out.println(p);
		}
		
		//merge
		entityManager.getTransaction().begin();
		TestTeam person1 = new TestTeam(19L, 20000L, "CHANGED1", "TESTER", 2L, 2L);
		person1=entityManager.merge(person1);
		entityManager.getTransaction().commit();
    
		System.out.println("*****Team Details*****");
		listTeam = entityManager.createQuery(" FROM TestTeam t").getResultList();
		for (TestTeam p : listTeam) {
			System.out.println(p);
		}
		
		entityManager.getTransaction().begin();
		person1.setName("CHANGED2");
		entityManager.getTransaction().commit();
		
		System.out.println("*****Team Details*****");
		listTeam = entityManager.createQuery(" FROM TestTeam t").getResultList();
		for (TestTeam p : listTeam) {
			System.out.println(p);
		}
		
		//createNativeQuery 
		Query query= entityManager.createNativeQuery("select name from test_team where id=:id");
		query.setParameter("id", 10);
		System.out.println(query.getSingleResult());
		
		
    	//createStoredProcedureQuery 
    	entityManager.getTransaction().begin();
    	StoredProcedureQuery query=entityManager.createStoredProcedureQuery("PRC_GET_PROJECT_NAME");
    	query.registerStoredProcedureParameter("V_NAME", String.class, ParameterMode.IN).setParameter("V_NAME", "MUR").
    	registerStoredProcedureParameter("V_PROJECT_NAME", String.class, ParameterMode.OUT);
    	String projectname =(String) query.getOutputParameterValue("V_PROJECT_NAME");
    	System.out.println(projectname);
    	
    	
    	//createNamedStoredProcedureQuery 
    	StoredProcedureQuery query1=entityManager.createNamedStoredProcedureQuery("projectName");
    	query1.setParameter("V_NAME", "MUR");
    	query1.execute();
    	String projectname1 =(String) query1.getOutputParameterValue("V_PROJECT_NAME");
    	System.out.println(projectname1);
    	
    	
    	//@NamedNativeQuery
    	Query namedQuery=entityManager.createNamedQuery("SelectCount");
    	System.out.println(namedQuery.getSingleResult());
    	
    	//@NamedQuery
    	Query namedQuery1=entityManager.createNamedQuery("SelectName").setParameter("ID", 10L);
    	System.out.println(namedQuery1.getSingleResult());
    	 
    	
		//unwrap 
    	Session session = entityManager.unwrap(Session.class);
    	String projectName = session.doReturningWork(connection -> {
    		try (CallableStatement function = connection.prepareCall("{? = call FNC_GET_PROJECT_NAME(?)}")) {
    			function.registerOutParameter(1, Types.VARCHAR);
    			function.setString(2, "MUR");
    			function.execute();
    			return function.getString(1);
    		}
    	});
    	System.out.println(projectName);
		*/
    	
    	
    	
    	
    /**Criteria **/
    	
    	//em.getTransaction().begin();
    	
    	
    	/*//Create an object of CriteriaBuilder
    	CriteriaBuilder criteriaBuilder=entityManager.getCriteriaBuilder();  
    	
    	//instance of CriteriaQuery interface to create a query object.
    	CriteriaQuery<TestTeam> criteriaQuery=criteriaBuilder.createQuery(TestTeam.class); 
    	
    	//CriteriaQuery object to set the query root.
    	Root<TestTeam> rootTeam=criteriaQuery.from(TestTeam.class);
    	
    	//select
    	//criteriaQuery.select(rootTeam.get("projectId"));
    	
    	//orderBy
    	//criteriaQuery.orderBy(criteriaBuilder.asc(rootTeam.get("id")));  
    	
    	//orderBydesc
    	//criteriaQuery.orderBy(criteriaBuilder.desc(rootTeam.get("id")));
    	
    	//specify type of query result.
    	CriteriaQuery<TestTeam> select = criteriaQuery.select(rootTeam);  
    	
    	Query query = entityManager.createQuery(select);  
    	List<TestTeam> teamList = query.getResultList();  
    	
    	for(TestTeam testTeam:teamList) {
    		System.out.println(testTeam);
    	}*/
    	
    	
    	//where
    	/*CriteriaBuilder criteriaBuilder=entityManager.getCriteriaBuilder();  
    	
    	AbstractQuery<TestTeam> abstractQuery=criteriaBuilder.createQuery(TestTeam.class);
    	AbstractQuery<TestTeam> abstractQuery1=criteriaBuilder.createQuery(TestTeam.class);
    	
    	Root<TestTeam> root= abstractQuery.from(TestTeam.class);
    	
    	abstractQuery.where(criteriaBuilder.greaterThan(root.get("experience"), 2));
    	
    	CriteriaQuery< TestTeam> criteriaQuery= ((CriteriaQuery<TestTeam>)abstractQuery).select(root);
    	TypedQuery< TestTeam>typedQuery= entityManager.createQuery(criteriaQuery);
    	List<TestTeam> testTeams=typedQuery.getResultList();
    	for(TestTeam testTeam:testTeams) {
    		System.out.println(testTeam);
    	}*/
    	
    	//groupBy
    /*	CriteriaBuilder criteriaBuilder=entityManager.getCriteriaBuilder();  
    	CriteriaQuery<Object[]> criteriaQuery = criteriaBuilder.createQuery(Object[].class);  
    	Root<TestTeam> root = criteriaQuery.from(TestTeam.class);  
    	criteriaQuery.multiselect(root.get("projectId"),criteriaBuilder.count(root)).groupBy(root.get("projectId"));
    	//select project_id, count(project_id) from test_team group by project_id;
    	
    	//having
    	//criteriaQuery.multiselect(root.get("projectId"),criteriaBuilder.count(root)).groupBy(root.get("projectId")).having(criteriaBuilder.greaterThan(root.get("projectId"), 3));
    	//select project_id, count(project_id)from test_team group by project_id having project_id>3;
    	System.out.print("ProjectId");  
    	System.out.println("   Count");  
    	List<Object[]> list = entityManager.createQuery(criteriaQuery).getResultList();  
    	for(Object[] object : list){  
    	    System.out.println(object[0] + "              " + object[1]);  
    	  
    	}  */
    	
    	
    	
    	/*em.getTransaction().commit();
    	
        em.close();*/
        //em.close();      
    }
}
