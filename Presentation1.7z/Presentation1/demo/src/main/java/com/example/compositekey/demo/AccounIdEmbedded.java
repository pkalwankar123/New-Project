package com.example.compositekey.demo;

import java.io.Serializable;

import javax.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Embeddable
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccounIdEmbedded implements Serializable {
    private String accountNumber;
    private String accountType;

}