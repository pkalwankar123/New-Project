package com.example.inheritancetableperclass.demo.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories("com.springdata.persistance.dao")
@ComponentScan("com.springdata")
public class HibernateConfiguration {

	public HibernateConfiguration() {
		super();
	}

	@Value("${spring.datasource.driverClassName}")
	private String DB_DRIVER;

	@Value("${spring.datasource.password}")
	private String SPRING_DATASOURCE_PASSWORD;

	@Value("${spring.datasource.url}")
	private String SPRING_DATASOURCE_URL;

	@Value("${spring.datasource.username}")
	private String SPRING_DATASOURCE_USERNAME;	

	@Value("${spring.jpa.properties.hibernate.dialect}")
	private String HIBERNATE_DIALECT;

	@Value("${spring.jpa.properties.hibernate.show_sql}")
	private String SPRING_HIBERNATE_SHOW_SQL;
	
	@Value("${spring.jpa.properties.hibernate.format_sql}")
	private String SPRING_HIBERNATE_FORMAT_SQL;

	@Value("${spring.jpa.hibernate.ddl-auto}")
	private String HIBERNATE_HBM2DDL_AUTO;

	@Value("${hibernate.entity.packagesToScan}")
	private String HIBERNATE_PACKAGES_TO_SCAN;

	@Value("${spring.datasource.jndi}")
	private String SPRING_DATASOURCE_JNDI;

	@Bean
	public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
		final LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
		em.setDataSource(dataSource());
		em.setPackagesToScan(new String[] { HIBERNATE_PACKAGES_TO_SCAN });

		final HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		em.setJpaVendorAdapter(vendorAdapter);
		em.setJpaProperties(additionalProperties());

		return em;
	}
	
	@Bean
    public PlatformTransactionManager transactionManager() {
        final JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());
        return transactionManager;
    }

	final Properties additionalProperties() {
		final Properties hibernateProperties = new Properties();
		hibernateProperties.setProperty("hibernate.dialect", HIBERNATE_DIALECT);
		hibernateProperties.setProperty("hibernate.show_sql", SPRING_HIBERNATE_SHOW_SQL);
		hibernateProperties.setProperty("hibernate.format_sql", SPRING_HIBERNATE_FORMAT_SQL);
		hibernateProperties.setProperty("hibernate.hbm2ddl.auto", HIBERNATE_HBM2DDL_AUTO);
		return hibernateProperties;
	}
	

//JDBC connection
	
    @Bean
    public DataSource dataSource()
    {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName(DB_DRIVER);
        dataSource.setUrl(SPRING_DATASOURCE_URL);
        dataSource.setUsername(SPRING_DATASOURCE_USERNAME);
        dataSource.setPassword(SPRING_DATASOURCE_PASSWORD);
        return dataSource;
    }

	@Bean
	public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
		return new PersistenceExceptionTranslationPostProcessor();
	}
}
