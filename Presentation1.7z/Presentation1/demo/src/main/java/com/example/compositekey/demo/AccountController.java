package com.example.compositekey.demo;

public class AccountController {

}
