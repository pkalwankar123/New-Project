package com.example.compositekey.demo;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountEmbeddable {

	@EmbeddedId
	private AccounIdEmbedded accounIdEmbedded;
	
	@Column
	private String firstName;
	
	@Column
	private String lastName;

}
