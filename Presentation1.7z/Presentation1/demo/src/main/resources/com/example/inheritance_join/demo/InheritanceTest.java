package com.example.inheritance_join.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class InheritanceTest {

	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("Persistence1");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		System.out.println("TEST");
		// create one employee
		Employee1 employee = new Employee1();
		employee.setName("John");
		employee.setSalary(5000);
		em.persist(employee);

		// create one manager
		Manager1 manager = new Manager1();
		manager.setName("Trisha");
		manager.setSalary(8000);
		manager.setDepartmentName("Sales");
		em.persist(manager);

		System.out.println("Added one employee and manager to database.");
		em.getTransaction().commit();
		em.close();
		factory.close();
	}

}