
import { Component,OnInit} from "@angular/core";
import { ParkingService } from "./app.parkingservice";
import { Owner } from "./app.owner";
import { Vehicle } from "./app.vehicle";
import {FormGroup,FormControl, Validators} from "@angular/forms";

@Component({
selector:'vehicle-app',
templateUrl:'app.vehicle.html'

})
export class VehicleComponent {

    
    number:string;
    description:string;
   ownerid:Owner
   vehicleForm = new FormGroup({
    ownerid:new FormControl(''),
    vehicleNumber:new FormControl(''),
    vehicleDescription:new FormControl('')
   
});


    constructor(private veheservice:ParkingService){}

    vehicle:any={
       
    };

    addVehicle(){
      this.veheservice.addAllVehicle(this.vehicleForm.value).subscribe((data)=>console.log(data));
   }
}





 

