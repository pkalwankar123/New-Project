import {Parking} from './app.parking'

export class Parkingslot{
    id:number;
    name:string;
    price:number;
    description:string;
    parking:Parking;
}