import{Injectable} from '@angular/core';
import{HttpClient} from '@angular/common/http';
import{Observable} from "rxjs"
import { Owner } from './app.owner';
import { Vehicle } from './app.vehicle';
@Injectable({
    providedIn:'root'
})
export class ParkingService{
   
    constructor(private http:HttpClient){}
   
    
    addAllOwner(userdata:any){
        let input=new FormData();
        input.append("id",userdata.ownerid);
        input.append("name",userdata.ownerName);
        input.append("mobNumber",userdata.ownerCantact);
        input.append("address.houseNumber",userdata.ownerHousnumber);
        input.append("address.street",userdata.ownerStreet);
        input.append("address.city",userdata.ownerCity);
        input.append("address.pincode",userdata.ownerPincode);
        return this.http.post<any>("http://localhost:9091/parkingmgtsys/addowner",input);
    }
    



    //addAllVehicle(vehiAdd:any):any
    //{
    //let i:number=0;    
    //var input= new FormData();
    //input.append("owner.id",vehiAdd.ownerid);  //"id "= postman key   value =are form name 
    //console.log("chava"+vehiAdd.vehicles.length);
    
   // while(i<vehiAdd.vehicles.length) {
    //console.log("count"+i);
    
  //  input.append("vehiAdd.vehicles["+i+"].number", vehiAdd.vehicles[i].number);
    //input.append("vehiAdd.vehicles["+i+"].description", vehiAdd.vehicles[i].description);
    
  //  i++;
   // }  
     
    //return this.http.post("http://localhost:9091/parkingmgtsys/addvehicle",input)
   // }
    
    


    addAllVehicle(vehicle:any){
        let input=new FormData();
        input.append("owner.id",vehicle.ownerid);
        input.append("number",vehicle.vehicleNumber);
       input.append("description",vehicle.vehicleDescription);
        
       
  return this.http.post<any>("http://localhost:9091/parkingmgtsys/addvehicle",input)
 }
    searchAllVehicle(vehicles:any)
    {
        let input=new FormData();
        input.append("number",vehicles.number);
        return this.http.post<any>("http://localhost:9091/parkingmgtsys/searchvehicle",input);
 
    }

    addAllParking(parking:any){
        let input=new FormData();
        input.append("owner.id",parking.ownerid);
        input.append("id",parking.parkingid);
        input.append("location",parking.parkingLocation);
        
       
        return this.http.post<any>("http://localhost:9091/parkingmgtsys/addparking",input)
    }

    addAllParkingslot(userdata:any){

        console.log(userdata);
        console.log(userdata.parkingid);
        console.log(userdata.startDate);
        console.log(userdata.endDate);
        console.log(userdata.starttime);
        console.log(userdata.endtime);
        
        let input=new FormData();
        input.append("parking.id",userdata.parkingid);
        input.append("startdate",userdata.startDate);
        input.append("enddate",userdata.endDate);
        input.append("starttime",userdata.starttime);
        input.append("endtime",userdata.endtime);
        
        return this.http.post("http://localhost:9091/parkingmgtsys/addparkingslot",input);
    }


   
    }