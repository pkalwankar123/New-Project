export class Parking{
    id:number;
    location:string;
    
}