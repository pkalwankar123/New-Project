export class Address{
    houseNumber:string;
    street:string;
    city:string;
    pincode:number;
}