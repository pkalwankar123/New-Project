import { Component,OnInit} from "@angular/core";
import { ParkingService } from "./app.parkingservice";
import { Parkingslot } from "./app.parkslot";
import {FormGroup,FormControl, Validators} from "@angular/forms";

@Component({
selector:'parkingslot-app',
templateUrl:'app.parkingslot.html'

})
export class ParkingslotComponent{
    parkingid:number;
    startdate:string;
    enddate:number;
    starttime:string;
    endtime:number;
  
    parkingslot:Parkingslot[];
    model : any ={};

    

    phoneNumber = "^(\+\d{1,3}[- ]?)?\d{10}$";
    parkingslotForm = new FormGroup({
        parkingid:new FormControl(''),
        startDate:new FormControl(''),
        endDate:new FormControl(''),
        starttime:new FormControl(''),
        endtime:new FormControl(''),
       
});
   
    constructor(private oweservice:ParkingService){}

    owe:any={"parking":
    {"id":this.parkingid},
    "startdate":this.startdate,
    "enddate":this.enddate,
    "starttime":this.starttime,
    "endtime":this.endtime
        };

    

    addParkingslot(){


console.log(this.owe);
       this.oweservice.addAllParkingslot(this.parkingslotForm.value).subscribe(
           response => console.log('Success', response)
          
       );
    console.log(this.parkingslotForm.value);
    }
}