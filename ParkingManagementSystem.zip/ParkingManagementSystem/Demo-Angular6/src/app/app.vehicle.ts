import {Address} from './app.address'
import {Owner} from './app.owner'


export class Vehicle{
    number:string;
    description:string;
    //owner:Owner;
}