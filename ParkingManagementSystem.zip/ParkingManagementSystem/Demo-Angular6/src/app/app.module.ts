﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import {HttpClientModule} from '@angular/common/http';
import { FormsModule }  from '@angular/forms';
import { OwnerComponent }  from './app.ownercomponent';
import { VehicleComponent }  from './app.vehiclecomponent';
import { ParkingComponent }  from './app.parkingcomponent';
import { ParkingService }  from './app.parkingservice';
import { searchvehicle }  from './app.searchvehicle';
import{Routes,RouterModule}from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { ParkingslotComponent }  from './app.parkingslot';

ParkingslotComponent
const route:Routes=[

    {path:"addOwner",component:OwnerComponent},
    {path:"addVehicle",component:VehicleComponent},
    {path:"searchVehicle",component:searchvehicle},
    {path:"addParking",component:ParkingComponent},
    {path:"addParkingslot",component:ParkingslotComponent}
];

@NgModule({
    imports: [
        BrowserModule,
        FormsModule,
        HttpClientModule,RouterModule.forRoot(route),
        ReactiveFormsModule
        
    ],
    declarations: [
        AppComponent,
        OwnerComponent,VehicleComponent,searchvehicle,ParkingComponent,ParkingslotComponent
      
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }