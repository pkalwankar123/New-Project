import {Address} from './app.address'
import { Vehicle } from './app.vehicle';


export class Owner{
    id:number;
    name:string;
    mobNumber:number;
    address:Address;
    //vehicles:Vehicle[];
}